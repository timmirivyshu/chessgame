# ChessGame
This is a simple chess game project that is explained in a youtube video.
[Video Link](https://www.youtube.com/watch?v=vO7wHV0HB8w)
